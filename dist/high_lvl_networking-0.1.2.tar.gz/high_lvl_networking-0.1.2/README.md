# High Level Networking

## Requirements

None

## Install

```bash
pip install high_lvl_networking
```

## Usage

### Server

```python
from high_lvl_networking import Server
```

### Client

```python
from high_lvl_networking import Client
```
